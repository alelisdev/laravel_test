<?php

namespace App\Http\Controllers\Games\SpinData\FortuneRabbit;

class FortuneRabbitDemo
{
    /**
     * @return array
     */
    public static function getDemo(): array
    {
        return [];
    }
}
