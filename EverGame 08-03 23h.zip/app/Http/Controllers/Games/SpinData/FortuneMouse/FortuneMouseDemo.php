<?php

namespace App\Http\Controllers\Games\SpinData\FortuneMouse;

class FortuneMouseDemo
{
    /**
     * @return array
     */
    public static function getDemo(): array
    {
        return [];
    }
}
