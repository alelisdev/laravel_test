<?php

namespace App\Filament\Resources\VipResource\Pages;

use App\Filament\Resources\VipResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateVip extends CreateRecord
{
    protected static string $resource = VipResource::class;
}
