<?php

namespace App\Http\Controllers\Games\SpinData\PhoenixRises;

class PhoenixRisesDemo
{
    /**
     * @return array
     */
    public static function getDemo(): array
    {
        return [];
    }
}
